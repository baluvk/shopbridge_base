# Shopbridge_Base
This repository contains a .Net Standard 5 and C# solution, which can be used as a base to start upon, for the backend shopbridge assignment.
