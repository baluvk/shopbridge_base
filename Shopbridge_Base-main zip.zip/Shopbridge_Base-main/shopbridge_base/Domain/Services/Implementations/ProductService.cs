﻿using Microsoft.Extensions.Logging;
using Shopbridge_base.Data.Repository;
using Shopbridge_base.Domain.Models;
using Shopbridge_base.Domain.Services.Interfaces;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Shopbridge_base.Domain.Services
{
    public class ProductService : IProductService
    {
        


        private readonly  IRepository<Product> iRepository;

        public ProductService(IRepository<Product> product)
        {
            this.iRepository = product;
        }

        public void Delete(int id)
        {
            iRepository.Delete(id);
        }

        public IEnumerable<Product> GetAll()
        {
         return  iRepository.GetAll();
        }

        public Product GetById(int id)
        {
            return iRepository.GetById(id);
        }

        public void Insert(Product obj)
        {
            iRepository.Insert(obj);
        }

        public void Update(Product obj)
        {
            iRepository.Update(obj);
        }

        public void Save()
        {
            iRepository.Save();
        }
    }
}
